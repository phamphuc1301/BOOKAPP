document.addEventListener("DOMContentLoaded",function(){
	var clickHere = document.getElementById('disable');
	clickHere.onclick = function() {
		$("#myModal").modal('show');
	}
})