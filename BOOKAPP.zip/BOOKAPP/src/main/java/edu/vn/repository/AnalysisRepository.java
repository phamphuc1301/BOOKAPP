package edu.vn.repository;

public interface AnalysisRepository {
  int analysis(String entity);
}
