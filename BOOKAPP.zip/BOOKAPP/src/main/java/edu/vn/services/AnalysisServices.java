package edu.vn.services;

public interface AnalysisServices {
  int analysis(String entity);
}
