package edu.vn.utils;

public class Constant {
  
  public static final String PAGE_INDEX = "index";
  
}
