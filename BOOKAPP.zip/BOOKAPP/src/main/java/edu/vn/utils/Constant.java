package edu.vn.utils;

public class Constant {
  
  public static final String PAGE_INDEX = "index";
  public static final String URL_LOGIN = "http://localhost:8080/BOOKAPP/appLogin";
  public static final String AR_5NEWEST = "get5newest";
  public static final String AR_ALL = "getall";
  public static final String AR_LISTVANHOC = "getlistvanhoc";
  public static final String AR_LISTTRINHTHAM = "getlisttrinhtham";
  public static final String AR_LISTKINHTE = "getlistkinhte";
  public static final String AR_LISTBLOG = "getlistblog";
}
